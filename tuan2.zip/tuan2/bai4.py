def place_order(order_items, menu_prices):
    total_cost = 0
    for item, quantity in order_items.items():
        if item in menu_prices:
            total_cost += menu_prices[item] * quantity
        else:
            return f"Error: {item} is not available on the menu."
    return round(total_cost, 2)
menu = {"burger": 5, "fries": 2.5, "soda": 1.5}
order = {"burger": 2, "fries": 1}
print("Total order cost:", place_order(order, menu))  
# Output: 12.5