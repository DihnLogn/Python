def apply_discount(price, discount_percent):
    if price < 0 or discount_percent < 0 or discount_percent > 100:
        return "Invalid input"
    discount_amount = (discount_percent / 100) * price
    return round(price - discount_amount, 2)
# Example usage
print(apply_discount(100, 20))  # Output: 80.0
print(apply_discount(50, 10))   # Output: 45.0
print(apply_discount(200, 50))  # Output: 100.0