def track_expenses(expenses):
    if not expenses:
        return "No expenses recorded."
    total_spent = sum(expenses)
    average_expense = total_spent / len(expenses)
    return round(total_spent, 2), round(average_expense, 2)
expenses = [20, 15.5, 10, 5]
print("Total and average expenses:", track_expenses(expenses))