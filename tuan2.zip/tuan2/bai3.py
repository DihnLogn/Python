def calculate_salary(hours_worked, hourly_rate, bonus=0):
    if hours_worked < 0 or hourly_rate < 0 or bonus < 0:
        return "Invalid input"
    salary = (hours_worked * hourly_rate) + bonus
    return round(salary, 2)
print(calculate_salary(40, 15))       # Output: 600.0
print(calculate_salary(40, 15, 100))  # Output: 700.0